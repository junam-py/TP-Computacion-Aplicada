#!/bin/bash

# Script de backup - backup_full.sh
# Uso: backup_full.sh <origen> <destino>

# Función de ayuda
mostrar_ayuda() {
    echo "=========================================="
    echo "Script de Backup - backup_full.sh"
    echo "=========================================="
    echo ""
    echo "Uso: $0 [OPCIONES] <origen> <destino>"
    echo ""
    echo "Opciones:"
    echo "  -help       Muestra esta ayuda"
    echo ""
    echo "Argumentos:"
    echo "  origen      Directorio a respaldar (ej: /var/log)"
    echo "  destino     Directorio donde guardar backup (ej: /backup_dir)"
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo ""
    echo "El backup se guardará con formato: <nombre>_bkp_YYYYMMDD.tar.gz"
    echo "=========================================="
    exit 0
}

# Verificar si se pidió ayuda
if [ "$1" == "-help" ] || [ "$1" == "--help" ]; then
    mostrar_ayuda
fi

# Verificar argumentos
if [ $# -ne 2 ]; then
    echo "Error: Se requieren 2 argumentos (origen y destino)"
    echo "Use '$0 -help' para más información"
    exit 1
fi

ORIGEN=$1
DESTINO=$2

# Obtener fecha en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# Obtener nombre del directorio origen (sin la ruta completa)
NOMBRE_ORIGEN=$(basename "$ORIGEN")

# Nombre del archivo de backup
ARCHIVO_BACKUP="${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"
RUTA_COMPLETA="${DESTINO}/${ARCHIVO_BACKUP}"

# Validar que el directorio origen existe
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio origen '$ORIGEN' no existe o no está disponible"
    exit 1
fi

# Validar que el directorio destino existe
if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio destino '$DESTINO' no existe o no está disponible"
    exit 1
fi

# Validar que el destino es escribible
if [ ! -w "$DESTINO" ]; then
    echo "Error: No se tienen permisos de escritura en '$DESTINO'"
    exit 1
fi

# Realizar el backup
echo "=========================================="
echo "Iniciando backup..."
echo "Origen: $ORIGEN"
echo "Destino: $RUTA_COMPLETA"
echo "Fecha: $FECHA"
echo "=========================================="

tar -czf "$RUTA_COMPLETA" "$ORIGEN" 2>/dev/null

# Verificar si el backup fue exitoso
if [ $? -eq 0 ]; then
    TAMANO=$(du -h "$RUTA_COMPLETA" | cut -f1)
    echo "Backup completado exitosamente!"
    echo "Archivo: $ARCHIVO_BACKUP"
    echo "Tamaño: $TAMANO"
    echo "=========================================="
    exit 0
else
    echo "Error: Falló el backup de '$ORIGEN'"
    exit 1
fi
