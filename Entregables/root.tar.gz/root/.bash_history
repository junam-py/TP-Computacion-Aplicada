 poweroff
 poweroff
cat /etc/os-release 
apt update
apt upgrade -y
apt update
apt install openssh-server -y
cat /etc/apt/sources.list
ping -c 4 google.com
ping -c 4 8.8.8.8
apt update
cat /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian bullseye main contrib non-free
deb http://deb.debian.org/debian bullseye-updates main contrib non-free
deb http://security.debian.org/debian-security bullseye-security main contrib non-free
EOF

apt update
apt install openssh-server -y
rm /etc/apt/sources.list
cat > /etc/apt/sources.list << 'EOF'
cat /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian bullseye main contrib non-free
deb http://deb.debian.org/debian bullseye-updates main contrib non-free
deb http://security.debian.org/debian-security bullseye-security main contrib non-free
EOF

apt update
rm /etc/apt/sources.list
cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian bullseye main contrib non-free
deb http://deb.debian.org/debian bullseye-updates main contrib non-free
deb http://security.debian.org/debian-security bullseye-security main contrib non-free
EOF

apt update
apt install openssh-server -y
systemctl status ssh
systemctl enable ssh
mkdir -p /root/.ssh
chmod 700 /root/.ssh
apt install build-essential dkms linux-headers-$(uname -r) -y
poweroff
hostname set-hostname TPServer
hostnamectl
echo "TPServer" > /etc/hostname
nano /etc/host
nano /etc/hosts
hostnamectl
hostname
hostnamectl
ls -la /etc/hosts
nano /etc/hosts
vi /etc/hosts
hostname
hostnamectl
su -
su palermo
su
mkdir -p /mnt/cdrom
mount /dev/cdrom /mnt/cdrom
ls -la /mnt/cdrom
cd /mtn/cdrom
cd /mnt/cdrom/
sh ./VBoxLinuxAddtions.run
sh ./VBoxLinuxAdditions.run
reboot
lsmod | grep vbox
systemctl status vboxadd
systemctl status vboxadd-service
quit
reboot
poweroff
ip addr show
ip route show
cat /etc/resolv.conf
cat /etc/network/interfaces
cat > /etc/network/interfaces << 'EOF'
# The loopback network interface
auto lo
iface lo inet loopback

# The primary network interface
auto enp0s3
iface enp0s3 inet static
    address 192.168.0.227
    netmask 255.255.255.0
    gateway 192.168.0.1
    dns-nameservers 8.8.8.8 8.8.4.4
EOF

cat /etc/network/interfaces
systemctl restart networking
ip addr show enp0s3
ip route show
cat /etc/network/interfaces
ping -c 4 8.8.8.8
shootdown
poweroff
lsblk
fdisk -l
fdisk /dev/sdb
fdisk /dev/sdb
ls -la /dev/sdb*
lsblk
mkfs.ext4 /dev/sdb1
umount /dev/sdb1
umount /dev/sdb2 2>/dev/null
mkfs.ext4 /dev/sdb1
mkfs.ext4 /dev/sdb2
lsblk -f
mkdir -p /www_dir
mkdir -p /backup_dir
mount /dev/sdb1 /www_dir
mount /dev/sdb2 /backup_dir
df -h | grep /www_dir
df -h | grep /backup_dir
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
chown -R www-data:www-data /www_dir
chmod 755 /www_dir
chmod 644 /www_dir/index.php
chmod 644 /www_dir/logo.png
ls -la /www_dir/
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.backup
sed -i 's|DocumentRoot /var/www/html|DocumentRoot /www_dir|' /etc/apache2/sites-available/000-default.conf
cat >> /etc/apache2/sites-available/000-default.conf << 'EOF'
    <Directory /www_dir>
        Options Indexes FollowSymLinks
        AllowOverride None
        Require all granted
    </Directory>
EOF

cat /etc/apache2/sites-available/000-default.conf
cat >> /etc/apache2/apache2.conf << 'EOF'

<Directory /www_dir/>
    Options Indexes FollowSymLinks
    AllowOverride None
    Require all granted
</Directory>
EOF

apache2ctl configtest
systemctl restart apache2
systemctl status apache2
blkid /dev/sdb1
blkid /dev/sdb2
echo "UUID=$(blkid -s UUID -o value /dev/sdb1) /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdb2) /backup_dir ext4 defaults 0 2" >> /etc/fstab
cat /etc/fstab
umount /www_dir
umount /backup_dir
mount -a
df -h | grep -E "www_dir|backup_dir"
cat /proc/partitions > /root/particion
cat /proc/partitions > /proc/particion
mkdir -p /opt/scripts
cd /opt/scripts/
cat > /opt/scripts/backup_full.sh << 'EOF'
#!/bin/bash

# Script de backup - backup_full.sh
# Uso: backup_full.sh <origen> <destino>

# Función de ayuda
mostrar_ayuda() {
    echo "=========================================="
    echo "Script de Backup - backup_full.sh"
    echo "=========================================="
    echo ""
    echo "Uso: $0 [OPCIONES] <origen> <destino>"
    echo ""
    echo "Opciones:"
    echo "  -help       Muestra esta ayuda"
    echo ""
    echo "Argumentos:"
    echo "  origen      Directorio a respaldar (ej: /var/log)"
    echo "  destino     Directorio donde guardar backup (ej: /backup_dir)"
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo ""
    echo "El backup se guardará con formato: <nombre>_bkp_YYYYMMDD.tar.gz"
    echo "=========================================="
    exit 0
}

# Verificar si se pidió ayuda
if [ "$1" == "-help" ] || [ "$1" == "--help" ]; then
    mostrar_ayuda
fi

# Verificar argumentos
if [ $# -ne 2 ]; then
    echo "Error: Se requieren 2 argumentos (origen y destino)"
    echo "Use '$0 -help' para más información"
    exit 1
fi

ORIGEN=$1
DESTINO=$2

# Obtener fecha en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# Obtener nombre del directorio origen (sin la ruta completa)
NOMBRE_ORIGEN=$(basename "$ORIGEN")

# Nombre del archivo de backup
ARCHIVO_BACKUP="${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"
RUTA_COMPLETA="${DESTINO}/${ARCHIVO_BACKUP}"

# Validar que el directorio origen existe
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio origen '$ORIGEN' no existe o no está disponible"
    exit 1
fi

# Validar que el directorio destino existe
if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio destino '$DESTINO' no existe o no está disponible"
    exit 1
fi

# Validar que el destino es escribible
if [ ! -w "$DESTINO" ]; then
    echo "Error: No se tienen permisos de escritura en '$DESTINO'"
    exit 1
fi

# Realizar el backup
echo "=========================================="
echo "Iniciando backup..."
echo "Origen: $ORIGEN"
echo "Destino: $RUTA_COMPLETA"
echo "Fecha: $FECHA"
echo "=========================================="

tar -czf "$RUTA_COMPLETA" "$ORIGEN" 2>/dev/null

# Verificar si el backup fue exitoso
if [ $? -eq 0 ]; then
    TAMANO=$(du -h "$RUTA_COMPLETA" | cut -f1)
    echo "Backup completado exitosamente!"
    echo "Archivo: $ARCHIVO_BACKUP"
    echo "Tamaño: $TAMANO"
    echo "=========================================="
    exit 0
else
    echo "Error: Falló el backup de '$ORIGEN'"
    exit 1
fi
EOF

